﻿// Program 0
// CIS 200-76
// Fall 2020
// Due: 9/7/2020
// By:5337752

// File: Package.cs
//This text determines package dimensions 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public abstract class Package : Parcel //declare inhertiance
    {
        private double _length; //declare varaibles
        private double _width;
        private double _height;
        private double _weight;

        public Package(Address originAddress, Address destAddress, double pLength, double pwidth, double pHeight, double pWeight): base(originAddress, destAddress)
        {
            Length = pLength; //create and assign constructors
            Width = pwidth;
            Height = pHeight;
            Weight = pWeight;

        }

        public double Length 
        {
            get { return _length; } //backing field
            set 
            { if (value > 0)
                    _length = value; //validate length
            else 
                    throw new ArgumentOutOfRangeException(nameof(Length), value, $"{nameof(Length)} must be > 0");
            }
        }

        public double Width 
        { 
            get { return _width; } //same process

            set
            {
                if (value > 0)
                    _length = value; //same process
                else
                    throw new ArgumentOutOfRangeException(nameof(Width), value, $"{nameof(Width)} must be > 0");
            }
        }
    
        public double Height
        {
            get { return _height; } //same process
            set
            {
                if (value > 0)
                    _length = value; //same process
                else
                    throw new ArgumentOutOfRangeException(nameof(Height), value, $"{nameof(Height)} must be > 0");
            }
        }
    
        public double Weight
        {
            get { return _weight;} //same process
            set
            {
                if (value > 0)
                    _length = value; //same process
                else
                    throw new ArgumentOutOfRangeException(nameof(Weight), value, $"{nameof(Weight)} must be > 0");
            }
        }


        protected double TotalDimension // define total dimension
        {
            get
            {
                return (Length + Width + Height); //no set required 
                                                  //get return transformation
            }
        }

        public override String ToString() //create string output 
        {
            string NL = Environment.NewLine;

            return $"Package{NL}{base.ToString()}{NL}Length: {Length:N1}{NL}Width:  {Width:N1}{NL}" + $"Height:  {Height:N1}{NL}Weight: {Weight:N1}";


        }
    }
}
