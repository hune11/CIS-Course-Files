﻿// Program 0
// CIS 200-76
// Fall 2020
// Due: 9/7/2020
// By:5337752

// File: NextDayAirPackage.cs
//This text figures out package dimensions size weight and fees
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public class NextDayAirPackage : AirPackage
    {
        public decimal _expressFee;


        public NextDayAirPackage(Address originAddress, Address destAddress, double pLength, double pWidth, double pHeight, double pWeight, decimal _expFee)
                : base(originAddress, destAddress, pLength, pWidth, pHeight, pWeight) //create constructor
        {
            ExpressFee = _expFee; //express fee varaible
        }
          
        public decimal ExpressFee
        {
            get { return _expressFee; } //get value
            private set
            {
                if (value >= 0)
                    _expressFee = value; //validate value for express fee
                else
                    throw new ArgumentOutOfRangeException(nameof(ExpressFee), value, $"{nameof(ExpressFee)} must be >= 0");
            }
        }

        public override decimal CalcCost() //CalcCost function override 
        {
            const double DIM_FACTOR = .35;
            const double WEIGHT_FACTOR = .25;
            const double HEAVY_FACTOR = .2;
            const double LARGE_FACTOR = .22;

            decimal cost;

            cost = (decimal)(DIM_FACTOR * TotalDimension + WEIGHT_FACTOR * Weight) + ExpressFee;//cost formula 
            
            
            if ( IsHeavy())
            {
                cost  += (decimal)(HEAVY_FACTOR * Weight); //if heavy add cost 
            }


            if (IsLarge())
            {
                cost += (decimal)(LARGE_FACTOR * TotalDimension);   //if large add cost
            }

            return cost;    

        }

        public override string ToString() //output string
        {
            string NL = Environment.NewLine;
            return $"NextDay{base.ToString()}{NL}Express Fee: {ExpressFee:C}";

        }










    }
            
     
}
