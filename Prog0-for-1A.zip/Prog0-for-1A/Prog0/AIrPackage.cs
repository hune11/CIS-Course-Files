﻿// Program 0
// CIS 200-76
// Fall 2020
// Due: 9/7/2020
// By:5337752

// File: AirPackage.cs
//This text decides whether package is heavy or large
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace Prog0
{
    public abstract class AirPackage : Package
    {
        public const double HEAVY_THRESHOLD = 75;
        public const double LARGE_THRESHOLD = 100;


        public AirPackage(Address originAddress, Address destAddress, double pLength, double pWidth, double pHeight, double pWeight)
            : base(originAddress, destAddress, pLength, pWidth, pHeight, pWeight) //create constructor no body because of base
        {

        }


        public bool IsHeavy()
        {
            return (Weight >= HEAVY_THRESHOLD);//return a bool if package is heavy or is large
        }

        public bool IsLarge()
        {
            return (TotalDimension >= LARGE_THRESHOLD);
        }

        public override string ToString()
        {
            string NL = Environment.NewLine;
            return $"Air{base.ToString()}{NL}Heavy: {IsHeavy()}{NL}Large: {IsLarge()}"; //display is heavy or is large depending on dimension
        }
    }



}
