﻿// Program 0
// CIS 200-76
// Fall 2020
// Due: 9/7/2020
// By:5337752

// File: TwoDayAirPackage.cs
//This file creates the enumurator and delivery type 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public class TwoDayAirPackage : AirPackage
    {
        public enum Delivery {  Early, Saver } //define enumurator 

        private Delivery _deliveryType; //backing field

        public TwoDayAirPackage(Address originAddress, Address destAddress, double pLength, double pWidth, double pHeight, double pWeight, Delivery delType)
            : base(originAddress, destAddress, pLength, pWidth, pHeight, pWeight) //constructor 
        {
            DeliveryType = delType; //property
        }

        public Delivery DeliveryType
        {
            get
            {
                return _deliveryType;  //get value 
            }

            set
            {
                if (Enum.IsDefined(typeof(Delivery), value)) //within delivery type is there a value
                {
                    _deliveryType = value; //
                }

                else 
                    throw new ArgumentOutOfRangeException(nameof(DeliveryType), value,
                    $"{nameof(DeliveryType)} must be {nameof(Delivery.Early)} " + 
                    $"or {nameof(Delivery.Saver)}");   //else throw message
            }
        }




        public override decimal CalcCost() //ovveride calcCost
        {
            const double DIM_FACTOR = .18; //declare factors 
            const double WEIGHT_FACTOR = .2;
            const decimal DISCOUNT_FACTOR = .15M;

            decimal cost;
            cost = (decimal)(DIM_FACTOR * TotalDimension + WEIGHT_FACTOR * Weight); //formula for cost

            if (DeliveryType == Delivery.Saver) ;
            {
                cost *= (1 - DISCOUNT_FACTOR);
            }
            return  cost;   //if else for discount factor 

        }
        public override string ToString() //output to string
        {
            string NL = Environment.NewLine;
            return $"TwoDay{base.ToString()}{NL}Delivery Type: {DeliveryType}";
        }
    }
}
