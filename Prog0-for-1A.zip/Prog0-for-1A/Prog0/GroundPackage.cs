﻿// Program 0
// CIS 200-76
// Fall 2020
// Due: 9/7/2020
// By:5337752

// File: GroundPackage.cs
//This text decides fees based off distance
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public class GroundPackage : Package //invoke inheritance
    {
        public GroundPackage(Address originAddress, Address destAddress, double pLength, double pWidth, double pHeight, double pWeight)
            : base(originAddress, destAddress, pLength, pWidth, pHeight, pWeight) //create constructor
        { } //no body needed all done in base 

        public int ZoneDistance
        {
            get
            {
                const int FIRST_DIGIT_FACTOR = 10000; //delcare constant for zipcode
                int dist; //absent value

                dist = Math.Abs((OriginAddress.Zip / FIRST_DIGIT_FACTOR) - (DestinationAddress.Zip / FIRST_DIGIT_FACTOR)); //equation for value
                return dist; //return 
            }
        }

        public override decimal CalcCost() //initaite calcCost function
        {
            const double DIM_FACTOR = .15; //implmement using constants
            const double WEIGHT_FACTOR = .07;

            return (decimal)(DIM_FACTOR * TotalDimension + WEIGHT_FACTOR * (ZoneDistance + 1) * Weight); //formula for equation 

        }

        public override string ToString() //create output string
        {
            string NL = Environment.NewLine;

            return $"Ground{base.ToString()}{NL}Zone Distance: {ZoneDistance}"; 


        }
    }
}
