﻿//Grading ID; S2201 
//Program 3
//Due Date: 04/01/2022
//CIS 199-03
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Program_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
           //!!! Form shows up blank when ran, not sure why !!!
        }
        
        
        
        String[] gardenArray = { "Premium", "Standard", "Discount" }; //Giving values to an array

        double[] baseArray = { 1.1, 1, 0.9 };//Giving values to an array

        int[] flowerArray = { 10001, 10002, 10003, 10004, 10005, 10006, 10007 };//Giving values to an array

        double[] costArray = { 7.87, 9.51, 10.73, 9.99, 11.99, 5.00, 4.58 };//Giving values to an array

        int[] quantityArray = { 0, 5, 6, 10, 11, 20, 21 };//Giving values to an array

        int[] priceArray = { 0, 5, 10, 15 };//Giving values to an array

        private void calcButton_Click(object sender, EventArgs e)
        {



            bool flowerFound = false; //Assign bool to false
            bool gardenFound = false; //Assign bool to false
            bool discountFound = false; //Assign bool to false
            int num; //assign variables
            int quantity;//assign variables
            double gardenCost = 0;//assign variables
            double customerDiscount= 0;//assign variables
            int sub = quantityArray.Length - 1;//assign variables
            double totalCost;//assign variables
            double flowerPrice;//assign variables
            double basePrice;//assign variables
            double discountPrice;//assign variables
            double discountPrecentage;//assign variables
            double basePrecentage;//assign variables






            if (int.TryParse(itemNumber.Text, out num) && num >= 10001 && num <= 10007) //TryParse user input 
            { 
                if (int.TryParse(quantityNumber.Text, out quantity) && quantity > 0) //TryParse user input 
                {
                    if (gardenType.SelectedIndex.ToString() == "Premium" || gardenType.SelectedIndex.ToString() == "Standard" || gardenType.SelectedIndex.ToString() == "Discount") //Assign combo box
                    {
                        double costPerFlower = 0; //assign value

                        for (int x =0; x < flowerArray.Length && !flowerFound; ++x) //for statement
                        {
                            if (num == flowerArray[x]) //if statement for the for                                                  
                            {
                                flowerFound = true; //bool is true 
                                costPerFlower = costArray[x]; //give costPerFLower value 
                            }

                        }

                        for (int y =0; y < gardenArray.Length && !gardenFound; ++y) // for statement
                        {
                            if (gardenType.SelectedIndex == y) //if for combo box 
                            {
                                gardenFound = true; //bool is true 
                                gardenCost = baseArray[y]; //assign value for garden cost
                            }

                        }

                        while (sub > 0 && !discountFound) //while statement
                        {
                            if (quantity>= quantityArray[sub]) //if statement 
                                discountFound = true; //bool is true 
                            else //else 
                                --sub; //take away from sub 
                            
                        }
                        if (discountFound) //if statement 
                            customerDiscount = priceArray[sub]; //assign value to customer Discount




                        discountPrecentage = customerDiscount / 100; //assign discount percent value 
                        basePrecentage = gardenCost / 100; //assign base percent value 

                        flowerPrice = quantity * costPerFlower; //flower price equation 
                        basePrice = flowerPrice * basePrecentage; //baseprice equation 
                        discountPrice = flowerPrice - (flowerPrice * discountPrecentage); //discount price equation 
                        totalCost = basePrice * discountPrice; //total cost equation 



                        flowerCost.Text = $"{flowerPrice:C}"; //output value 
                        baseCost.Text = $"{basePrice:C}"; //output value 
                        discountPercent.Text = $"{discountPrice}"; //output value 
                        totalPrice.Text = $"{totalCost:C}"; //output value 



                    }
                    else
                    {
                        MessageBox.Show("Error! Please Choose: Premium, Standard or Discount"); //message box for if try parse fails 
                    }
                }
                else
                {
                    MessageBox.Show("Error! Please Enter A Quanitity Number > 0"); //message box for if try parse fails
                }

            }
            else
            {
                MessageBox.Show("Error! Please Enter A Valid Flower Number"); //message box for if try parse fails
            }
            
            
        }
    }
}
