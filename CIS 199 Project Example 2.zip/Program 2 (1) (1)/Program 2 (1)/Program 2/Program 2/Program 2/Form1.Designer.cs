﻿
namespace Program_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guests = new System.Windows.Forms.Label();
            this.nights = new System.Windows.Forms.Label();
            this.hotel = new System.Windows.Forms.Label();
            this.cost = new System.Windows.Forms.Label();
            this.numCost = new System.Windows.Forms.Label();
            this.numGuests = new System.Windows.Forms.TextBox();
            this.numNights = new System.Windows.Forms.TextBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.numStars = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // guests
            // 
            this.guests.AutoSize = true;
            this.guests.Location = new System.Drawing.Point(104, 90);
            this.guests.Name = "guests";
            this.guests.Size = new System.Drawing.Size(98, 13);
            this.guests.TabIndex = 0;
            this.guests.Text = "Number of Guests: ";
            // 
            // nights
            // 
            this.nights.AutoSize = true;
            this.nights.Location = new System.Drawing.Point(107, 135);
            this.nights.Name = "nights";
            this.nights.Size = new System.Drawing.Size(95, 13);
            this.nights.TabIndex = 1;
            this.nights.Text = "Number of Nights: ";
            // 
            // hotel
            // 
            this.hotel.AutoSize = true;
            this.hotel.Location = new System.Drawing.Point(107, 179);
            this.hotel.Name = "hotel";
            this.hotel.Size = new System.Drawing.Size(62, 13);
            this.hotel.TabIndex = 2;
            this.hotel.Text = "Hotel Stars:";
            // 
            // cost
            // 
            this.cost.AutoSize = true;
            this.cost.Location = new System.Drawing.Point(110, 274);
            this.cost.Name = "cost";
            this.cost.Size = new System.Drawing.Size(59, 13);
            this.cost.TabIndex = 3;
            this.cost.Text = "Hotel Cost:";
            // 
            // numCost
            // 
            this.numCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.numCost.Location = new System.Drawing.Point(208, 273);
            this.numCost.Name = "numCost";
            this.numCost.Size = new System.Drawing.Size(121, 23);
            this.numCost.TabIndex = 4;
            // 
            // numGuests
            // 
            this.numGuests.Location = new System.Drawing.Point(208, 90);
            this.numGuests.Name = "numGuests";
            this.numGuests.Size = new System.Drawing.Size(121, 20);
            this.numGuests.TabIndex = 5;
            // 
            // numNights
            // 
            this.numNights.Location = new System.Drawing.Point(208, 132);
            this.numNights.Name = "numNights";
            this.numNights.Size = new System.Drawing.Size(121, 20);
            this.numNights.TabIndex = 6;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(156, 221);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(75, 23);
            this.calcButton.TabIndex = 8;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // numStars
            // 
            this.numStars.Location = new System.Drawing.Point(208, 179);
            this.numStars.Name = "numStars";
            this.numStars.Size = new System.Drawing.Size(121, 20);
            this.numStars.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(439, 350);
            this.Controls.Add(this.numStars);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.numNights);
            this.Controls.Add(this.numGuests);
            this.Controls.Add(this.numCost);
            this.Controls.Add(this.cost);
            this.Controls.Add(this.hotel);
            this.Controls.Add(this.nights);
            this.Controls.Add(this.guests);
            this.Name = "Form1";
            this.Text = "Program 2 - Hotel Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label guests;
        private System.Windows.Forms.Label nights;
        private System.Windows.Forms.Label hotel;
        private System.Windows.Forms.Label cost;
        private System.Windows.Forms.Label numCost;
        private System.Windows.Forms.TextBox numGuests;
        private System.Windows.Forms.TextBox numNights;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.TextBox numStars;
    }
}

