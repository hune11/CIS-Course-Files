﻿//Grading ID: S2201 
//Program 2 
//March 11, 2022
//CIS 199-03
//This program takes a total of guests, nights and stars and uses prices related to those numbers to calculate the hotel cost. 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {

            const double guest1 = 100; //declare constant 
            const double guest2 = 150; //declare constant                                                                 
            const double guest3 = 250; //declare constant                                                                
            const double guest4 = 400; //declare constant                                                                 
                                                                                                      
            const double night1 = 100; //declare variable 
            const double night2 = 75; //declare variable 
            const double night3 = 25; //declare variable

            const double star1 = 1; //declare variable
            const double star2 = 1.5; //declare variable
            const double star3 = 2.5; //declare variable
            const double star4 = 3; //declare variable
            const double star5 = 4; //declare variable 

            double guestCost;//declare variable
            double nightCost;//declare variable
            double starCost;//declare variable
            double hotelCost;//declare variable
            double guest;//declare variable
            double nightCostTotal;//declare variable
            double night;//declare variable
            double star;//declare variable




            if (double.TryParse(numGuests.Text, out guest) && guest > 0 && guest <= 7) //Validate guest number input
            {
                if (double.TryParse(numNights.Text, out night) && night > 0) //Validate night number input 
                {
                    if (double.TryParse(numStars.Text, out star) && star > 0 && star <= 5) //Validate star number input 
                    {



                        {
                            if (star == 1) //if star = 1
                                starCost = star1; //starcost = star1 amount 
                            else if (star == 2) //if star = 2 
                                starCost = star2; //starcost = star2 amount 
                            else if (star == 3) //if star = 3
                                starCost = star3; //starcost = star3 amount 
                            else if (star == 4) //if star = 4 
                                starCost = star4; //starcost = star4 amount 
                            else //anything else 
                                starCost = star5; //starcost = star 5 amount
                             

                            if (guest == 1) //if guest = 1 
                                guestCost = guest1; //guestcost = guest1 amount 
                            else if (guest == 2) //if guest = 2
                                guestCost = guest2; //guestcost = guest2 amount 
                            else if (guest == 3) //if guest = 3 
                                guestCost = guest3; //guest cost = guest3 amount 
                            else //else
                                guestCost = guest4; //guestcost = guest4 amount 

                            if (night >= 1 && night <= 6) //if night is greater than 1 or equal to one and less than or equal to 6
                                nightCost = night1; //night cost = night 1 amount
                            else if (night >= 7 && night <= 30)//if night is greater 7 than or equal to one and less than or equal to 30
                                nightCost = night2; //nightcost = night2 amount
                            else //else
                                nightCost = night3; //nightcost = night3 amount

                        }

                        nightCostTotal = night * nightCost; //night cost equation 
                        hotelCost = (nightCostTotal + guestCost) * starCost; //total hotel cost equation 
                        numCost.Text = $"{hotelCost:C}"; //displays hotelcost in output label on form 

                    }



                    else MessageBox.Show("Error! Enter Valid Star Amount Between 1-5"); } //Prompts message box if TryParse conditions are not met 

                    else MessageBox.Show("Error! Enter Valid Night Amount Greater Than 1"); } //Prompts message box if TryParse conditions are not met 

                    else MessageBox.Show("Error! Enter Valid Guest Amount Between 1 - 7"); } //Prompts message box if TryParse conditions are not met 


      
        }

    }

                
        

