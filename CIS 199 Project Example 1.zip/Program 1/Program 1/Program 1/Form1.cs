﻿//Grading ID: S2201
//Program 1
//Due Date: February 15, 2022
//CIS 199-03
//This program calculates an estimate on material cost and labor cost for a shed based on user inputs. 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_1
{
    public partial class Program1 : Form
    {
        public Program1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            const double TENPERCENT = 1.1; //Gives the double constant TENPERCENT the value of 1.1 for extra 10% on costs.
            const double WINDOWFEE = 100; //Gives the double constant WINDOWFEE the value of 100 for window price. 
            

            double FRONTL; // declares the front label a double
            double SIDEL; // declares the side label as a double
            double HEIGHTL; // declares the height label as a double
            double WINDOW; // delcares the window label as a double 
            double COSTOFMATERIAL; // declares the cost materials as a double 
            double COSTOFLABOR; //declares cost of labor as a double 
            double TOTALSQF; // declares total square feet as a double 
            double PLUS10; //declares the extra 10 % variable as a double 
            double LABORCOST; //declares labor cost as a double
            double MATERIALCOST; //declares material cost as a double
            double TOTALCOST; // declares total cost as a double

            FRONTL = double.Parse(FRONTLENGTH.Text); //Gives user input to the FRONTL label as a double.
            SIDEL = double.Parse(SIDELENGTH.Text); //Gives user input to the SIDEL label sa a double.
            HEIGHTL = double.Parse(HEIGHTLENGTH.Text); //Gives user input to the HEIGHTL label as a double.
            COSTOFMATERIAL = double.Parse(COSTOFMAT.Text); //Gives user input to the COSTOFMATERIAL label as a double.
            COSTOFLABOR = double.Parse(COSTOFLAB.Text); //Gives user input to the COSTOFLABOR label as a double.
            WINDOW = int.Parse(WINDOWADD.Text); //Gives user input to the WINDOW label as an integer.
            
            
            TOTALSQF = (FRONTL * HEIGHTL * 2) + (SIDEL * HEIGHTL * 2) + (FRONTL * SIDEL); //Gives the equation to calcualte the total Square feet of the shed based off inputs given in the height side and front length textboxes. 
            PLUS10 = TOTALSQF * TENPERCENT; //Gives equation of the extra 10% calculation.
            LABORCOST = COSTOFLABOR * PLUS10; //gives equation of the cost of labor calculation. 
            MATERIALCOST = COSTOFMATERIAL * PLUS10; //gives equation of the cost of material calculation.
           
            if (WINDOW == 1) //If window input is = to 1 
            
                WINDOW = WINDOWFEE; //then the WINDOW label = 100

            TOTALCOST = LABORCOST + MATERIALCOST + WINDOW; //Adds together all variables needed to find the total cost of the shed.
            
            


            TOTALSQUAREFEET.Text = $"{TOTALSQF:F2}"; //Tells program to dispaly TOTAL.SQF outptut in the TOTALSQUAREFEET label 
            PLUS10PERCENT.Text = $"{PLUS10:F2}"; //Tells program to display PLUS10 output in the PLUS10PERCENT label 
            LABORCOSTPRICE.Text = $"{LABORCOST:C}"; //Tells program to display LABORCOST output in the LABORCOSTPRICE  label
            MATERIALCOSTPRICE.Text = $"{MATERIALCOST:C}"; //Tells program to display MATERIALCOST output in the MATERIALCOSTPRICE label
            TOTALCOSTAMOUNT.Text = $"{TOTALCOST:C}";  //Tells program to display TOTALCOST output in the TOTALCOSTAMOUNT label. 
        }

        private void MATERIALCOSTPRICE_Click(object sender, EventArgs e)
        {

        }
    }
}
