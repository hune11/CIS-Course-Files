﻿
namespace Program_1
{
    partial class Program1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.FRONTLENGTH = new System.Windows.Forms.TextBox();
            this.SIDELENGTH = new System.Windows.Forms.TextBox();
            this.HEIGHTLENGTH = new System.Windows.Forms.TextBox();
            this.WINDOWADD = new System.Windows.Forms.TextBox();
            this.COSTOFMAT = new System.Windows.Forms.TextBox();
            this.COSTOFLAB = new System.Windows.Forms.TextBox();
            this.TOTALSQUAREFEET = new System.Windows.Forms.Label();
            this.PLUS10PERCENT = new System.Windows.Forms.Label();
            this.LABORCOSTPRICE = new System.Windows.Forms.Label();
            this.MATERIALCOSTPRICE = new System.Windows.Forms.Label();
            this.TOTALCOSTAMOUNT = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(87, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Dry Wall and Window Cost Calculator";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(71, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Length of Front (ft):";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(74, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Length of Side (ft);";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(112, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Height (ft):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 171);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Windows? (1- Yes, 0 - NO)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 224);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Cost of Dry Wall Per SQ Foot:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(31, 250);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Cost of Labor Per SQ Foot:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(53, 279);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Total SQ feet needed:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(111, 303);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "10% Extra";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(107, 335);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Labor Cost:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(97, 361);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Material Cost:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(96, 389);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 13);
            this.label12.TabIndex = 11;
            this.label12.Text = "Total Cost:";
            // 
            // FRONTLENGTH
            // 
            this.FRONTLENGTH.Location = new System.Drawing.Point(171, 42);
            this.FRONTLENGTH.Name = "FRONTLENGTH";
            this.FRONTLENGTH.Size = new System.Drawing.Size(100, 20);
            this.FRONTLENGTH.TabIndex = 12;
            // 
            // SIDELENGTH
            // 
            this.SIDELENGTH.Location = new System.Drawing.Point(171, 69);
            this.SIDELENGTH.Name = "SIDELENGTH";
            this.SIDELENGTH.Size = new System.Drawing.Size(100, 20);
            this.SIDELENGTH.TabIndex = 13;
            // 
            // HEIGHTLENGTH
            // 
            this.HEIGHTLENGTH.Location = new System.Drawing.Point(171, 104);
            this.HEIGHTLENGTH.Name = "HEIGHTLENGTH";
            this.HEIGHTLENGTH.Size = new System.Drawing.Size(100, 20);
            this.HEIGHTLENGTH.TabIndex = 14;
            // 
            // WINDOWADD
            // 
            this.WINDOWADD.Location = new System.Drawing.Point(171, 168);
            this.WINDOWADD.Name = "WINDOWADD";
            this.WINDOWADD.Size = new System.Drawing.Size(100, 20);
            this.WINDOWADD.TabIndex = 15;
            // 
            // COSTOFMAT
            // 
            this.COSTOFMAT.Location = new System.Drawing.Point(171, 221);
            this.COSTOFMAT.Name = "COSTOFMAT";
            this.COSTOFMAT.Size = new System.Drawing.Size(100, 20);
            this.COSTOFMAT.TabIndex = 16;
            // 
            // COSTOFLAB
            // 
            this.COSTOFLAB.Location = new System.Drawing.Point(171, 247);
            this.COSTOFLAB.Name = "COSTOFLAB";
            this.COSTOFLAB.Size = new System.Drawing.Size(100, 20);
            this.COSTOFLAB.TabIndex = 17;
            // 
            // TOTALSQUAREFEET
            // 
            this.TOTALSQUAREFEET.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TOTALSQUAREFEET.Location = new System.Drawing.Point(171, 275);
            this.TOTALSQUAREFEET.Name = "TOTALSQUAREFEET";
            this.TOTALSQUAREFEET.Size = new System.Drawing.Size(100, 23);
            this.TOTALSQUAREFEET.TabIndex = 18;
            // 
            // PLUS10PERCENT
            // 
            this.PLUS10PERCENT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PLUS10PERCENT.Location = new System.Drawing.Point(171, 302);
            this.PLUS10PERCENT.Name = "PLUS10PERCENT";
            this.PLUS10PERCENT.Size = new System.Drawing.Size(100, 23);
            this.PLUS10PERCENT.TabIndex = 19;
            // 
            // LABORCOSTPRICE
            // 
            this.LABORCOSTPRICE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LABORCOSTPRICE.Location = new System.Drawing.Point(171, 334);
            this.LABORCOSTPRICE.Name = "LABORCOSTPRICE";
            this.LABORCOSTPRICE.Size = new System.Drawing.Size(100, 23);
            this.LABORCOSTPRICE.TabIndex = 20;
            // 
            // MATERIALCOSTPRICE
            // 
            this.MATERIALCOSTPRICE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MATERIALCOSTPRICE.Location = new System.Drawing.Point(171, 361);
            this.MATERIALCOSTPRICE.Name = "MATERIALCOSTPRICE";
            this.MATERIALCOSTPRICE.Size = new System.Drawing.Size(100, 23);
            this.MATERIALCOSTPRICE.TabIndex = 21;
            this.MATERIALCOSTPRICE.Click += new System.EventHandler(this.MATERIALCOSTPRICE_Click);
            // 
            // TOTALCOSTAMOUNT
            // 
            this.TOTALCOSTAMOUNT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TOTALCOSTAMOUNT.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TOTALCOSTAMOUNT.Location = new System.Drawing.Point(171, 388);
            this.TOTALCOSTAMOUNT.Name = "TOTALCOSTAMOUNT";
            this.TOTALCOSTAMOUNT.Size = new System.Drawing.Size(100, 23);
            this.TOTALCOSTAMOUNT.TabIndex = 22;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(115, 434);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(156, 23);
            this.button1.TabIndex = 23;
            this.button1.Text = "Calculate Estimate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Program1
            // 
            this.AcceptButton = this.button1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(376, 503);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.TOTALCOSTAMOUNT);
            this.Controls.Add(this.MATERIALCOSTPRICE);
            this.Controls.Add(this.LABORCOSTPRICE);
            this.Controls.Add(this.PLUS10PERCENT);
            this.Controls.Add(this.TOTALSQUAREFEET);
            this.Controls.Add(this.COSTOFLAB);
            this.Controls.Add(this.COSTOFMAT);
            this.Controls.Add(this.WINDOWADD);
            this.Controls.Add(this.HEIGHTLENGTH);
            this.Controls.Add(this.SIDELENGTH);
            this.Controls.Add(this.FRONTLENGTH);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Program1";
            this.Text = "Program 1 ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox FRONTLENGTH;
        private System.Windows.Forms.TextBox SIDELENGTH;
        private System.Windows.Forms.TextBox HEIGHTLENGTH;
        private System.Windows.Forms.TextBox WINDOWADD;
        private System.Windows.Forms.TextBox COSTOFMAT;
        private System.Windows.Forms.TextBox COSTOFLAB;
        private System.Windows.Forms.Label TOTALSQUAREFEET;
        private System.Windows.Forms.Label PLUS10PERCENT;
        private System.Windows.Forms.Label LABORCOSTPRICE;
        private System.Windows.Forms.Label MATERIALCOSTPRICE;
        private System.Windows.Forms.Label TOTALCOSTAMOUNT;
        private System.Windows.Forms.Button button1;
    }
}

