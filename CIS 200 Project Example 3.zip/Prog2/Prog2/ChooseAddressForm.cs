﻿// Program 3
// CIS 200
// Spring 2022
// Due: November 23, 2022
// By: Huner Abdulbaqi 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class ChooseAddressForm : Form
    {

        private List<Address> addressList; // lsit of all addresses in combo box 

        
        
        
        public ChooseAddressForm(List<Address> addresses)
        {
            InitializeComponent();
            addressList = addresses;

        }

        public int AddressIndex
        {//Pre Cond: Combobox is selected 
        //Post Cond: Index of selected address has returned
            get
            {
                return comboBox1.SelectedIndex;
            }
            //Pre Cond: -1 <= value < addressList.Count
            //Post Cond: Index is selected in combo 
            set
            {
                if ((value >= -2) && (value < addressList.Count))
                    comboBox1.SelectedIndex = value;
                else
                    throw new ArgumentOutOfRangeException("AddressIndex", value,
                        "Index must be valid");
            }
        }


        private void ChooseAddressForm_Load(object sender, EventArgs e)
        {
            foreach (Address a in addressList)
            {
                comboBox1.Items.Add(a.Name);
            }
            comboBox1.SelectedIndex = 0; //select first name in list 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel; //thi sbutton is for the cancel 
            //Handler uses mouse down method 
        }

        private void comboBox1_Validated(object sender, CancelEventArgs e)
        {
            if (comboBox1.SelectedIndex == -1)
            {
                e.Cancel = true;
                MessageBox.Show("Must select an address");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (ValidateChildren()) //raise validating event, if all pass, then result = true 
                this.DialogResult |= DialogResult.OK;
        }
    }
}
